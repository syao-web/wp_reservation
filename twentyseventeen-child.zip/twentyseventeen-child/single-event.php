<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<div class="wrap" id="event">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			
			<?php
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();
				
				get_template_part( 'template-parts/post/content', get_post_format() );
				
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;
				
				the_post_navigation(
					array(
						'prev_text' => '<span class="screen-reader-text">' . __( 'Previous Post', 'twentyseventeen' ) . '</span><span aria-hidden="true" class="nav-subtitle">' . __( 'Previous', 'twentyseventeen' ) . '</span> <span class="nav-title"><span class="nav-title-icon-wrapper">' . twentyseventeen_get_svg( array( 'icon' => 'arrow-left' ) ) . '</span>%title</span>',
						'next_text' => '<span class="screen-reader-text">' . __( 'Next Post', 'twentyseventeen' ) . '</span><span aria-hidden="true" class="nav-subtitle">' . __( 'Next', 'twentyseventeen' ) . '</span> <span class="nav-title">%title<span class="nav-title-icon-wrapper">' . twentyseventeen_get_svg( array( 'icon' => 'arrow-right' ) ) . '</span></span>',
					)
				);
			
			endwhile; // End of the loop.
			?>
			
			
			
			
			<div id="event_reservation_wrap">
				<?php $imgid = get_field('event_date01'); ?>
				<?php if(empty($imgid)):?>
				<?php else:?>
					<div class="event_con">
						<div class="event_date">
							<p><?php the_field('event_date01'); ?></p>
						</div>
						<div class="event_btn_wrap">
							<a class="event_btn" href="http://sytestpage.net/iwanaga/event_reservation?event-date=<?php the_field('event_date01'); ?>&event-title=<?php the_field('event_title01'); ?>">予約する</a>
						</div>
					</div>
				<?php endif;?>
				
				<?php $imgid = get_field('event_date02'); ?>
				<?php if(empty($imgid)):?>
				<?php else:?>
					<div class="event_con">
						<div class="event_date">
							<p><?php the_field('event_date02'); ?></p>
						</div>
						<div class="event_btn_wrap">
							<a class="event_btn" href="http://sytestpage.net/iwanaga/event_reservation?event-date=<?php the_field('event_date02'); ?>&event-title=<?php the_field('event_title01'); ?>">予約する</a>
						</div>
					</div>
				<?php endif;?>
				
				<?php $imgid = get_field('event_date03'); ?>
				<?php if(empty($imgid)):?>
				<?php else:?>
					<div class="event_con">
						<div class="event_date">
							<p><?php the_field('event_date03'); ?></p>
						</div>
						<div class="event_btn_wrap">
							<a class="event_btn" href="http://sytestpage.net/iwanaga/event_reservation?event-date=<?php the_field('event_date03'); ?>&event-title=<?php the_field('event_title01'); ?>">予約する</a>
						</div>
					</div>
				<?php endif;?>
				
				<?php $imgid = get_field('event_date04'); ?>
				<?php if(empty($imgid)):?>
				<?php else:?>
					<div class="event_con">
						<div class="event_date">
							<p><?php the_field('event_date04'); ?></p>
						</div>
						<div class="event_btn_wrap">
							<a class="event_btn" href="http://sytestpage.net/iwanaga/event_reservation?event-date=<?php the_field('event_date04'); ?>&event-title=<?php the_field('event_title01'); ?>">予約する</a>
						</div>
					</div>
				<?php endif;?>
				
				<?php $imgid = get_field('event_date05'); ?>
				<?php if(empty($imgid)):?>
				<?php else:?>
					<div class="event_con">
						<div class="event_date">
							<p><?php the_field('event_date05'); ?></p>
						</div>
						<div class="event_btn_wrap">
							<a class="event_btn" href="http://sytestpage.net/iwanaga/event_reservation?event-date=<?php the_field('event_date05'); ?>&event-title=<?php the_field('event_title01'); ?>">予約する</a>
						</div>
					</div>
				<?php endif;?>
			</div>
			
			
			<style>
				#event_reservation_wrap{
					width: 100%;
					margin-top: 25px;
				}
				.event_con{
					width:100%;
					overflow: hidden;
					margin-bottom: 25px;
					padding-bottom: 25px;
					border-bottom: 1px solid #eee;
					text-align: center;
				}
				.event_date{
					width:50%;
					float:left;
				}
				.event_date p{
					margin-bottom:0;
					padding: 5px 0;
				}
				.event_btn_wrap{
					width:50%;
					float:left;
				}
				.event_btn_wrap a.event_btn{
					color:#000;
					background-color:#ffadad;
					padding: 5px 15px;
					display: inline-block;
					border-radius:2px;
				}
			</style>
			
			
			
			
			
		</main><!-- #main -->
	</div><!-- #primary -->
	<?php get_sidebar(); ?>
</div><!-- .wrap -->

<?php
get_footer();
